// Chioccia — plug-in editor (original code)
#include "PluginEditor.h"

#include "Layout.h"
#include "Presets.h"

namespace chioccia
{
using namespace juce;
namespace L = ui::layout;

ChiocciaEditor::ChiocciaEditor (ChiocciaProcessor& p)
    : AudioProcessorEditor (p),
      processor (p),
      vu ([&p] { return ui::VuMeter::Reading { p.vuShowsOutput(), p.vuShowsOutput() ? p.getEngine().getOutputRmsDb()
                                                                                       : p.getEngine().getGainReductionDb() }; }),
      advanced (p)
{
    setLookAndFeel (&lnf);
    auto& s = p.getState();

    addAndMakeVisible (facePlate);
    facePlate.setBufferedToImage (true);

    auto setupKnob = [this] (Slider& k, const char* styleName, const String& tip, const String& title)
    {
        k.setSliderStyle (Slider::RotaryHorizontalVerticalDrag);
        k.setTextBoxStyle (Slider::NoTextBox, true, 0, 0);
        k.setRotaryParameters (MathConstants<float>::pi * 1.25f, MathConstants<float>::pi * 2.75f, true);
        k.getProperties().set (ui::style::key, styleName);
        k.setPopupDisplayEnabled (true, true, this);
        k.setTooltip (tip);
        k.setTitle (title);
        addAndMakeVisible (k);
    };
    setupKnob (gain, "bigKnob", "Make-up gain of the wet path (50 = 0 dB). It does not change the amount of compression.", "Gain");
    setupKnob (peakReduction, "bigKnob", "Side-chain gain: how much the opto cell compresses.", "Peak Reduction");
    setupKnob (outputTrim, "trimKnob", "Output trim after the dry/wet sum.", "Output Trim");
    outputTrim.setPopupDisplayEnabled (false, false, nullptr);

    mix.setSliderStyle (Slider::LinearHorizontal);
    mix.setTextBoxStyle (Slider::NoTextBox, true, 0, 0);
    mix.getProperties().set (ui::style::key, "mix");
    mix.setTooltip ("Dry/wet blend. 0 % = untouched dry signal (delay-compensated), 100 % = fully processed.");
    mix.setTitle ("Mix");
    addAndMakeVisible (mix);

    compLimit.getProperties().set (ui::style::key, "bat");
    compLimit.setTooltip ("Down = Compress (soft, ~4:1). Up = Limit (higher ratio, harder knee).");
    compLimit.setTitle ("Compress / Limit");
    power.getProperties().set (ui::style::key, "batInverted");
    power.setTooltip ("Up = processing ON. Down = bypass (latency-compensated, click-free).");
    power.setTitle ("Power (bypass)");
    vuMode.getProperties().set (ui::style::key, "segment");
    vuMode.getProperties().set (ui::style::segmentLeft, "GR");
    vuMode.getProperties().set (ui::style::segmentRight, "OUT");
    vuMode.setTooltip ("VU meter shows Gain Reduction or Output level.");
    vuMode.setTitle ("VU meter mode");
    for (auto* b : { &compLimit, &power, &vuMode })
        addAndMakeVisible (*b);

    gainAtt  = std::make_unique<SliderAttachment> (s, params::id::gain, gain);
    prAtt    = std::make_unique<SliderAttachment> (s, params::id::peakReduction, peakReduction);
    outAtt   = std::make_unique<SliderAttachment> (s, params::id::outputTrim, outputTrim);
    mixAtt   = std::make_unique<SliderAttachment> (s, params::id::mix, mix);
    compAtt  = std::make_unique<ButtonAttachment> (s, params::id::compLimit, compLimit);
    powerAtt = std::make_unique<ButtonAttachment> (s, params::id::bypass, power);
    vuAtt    = std::make_unique<ButtonAttachment> (s, params::id::vuMode, vuMode);

    addAndMakeVisible (vu);
    addAndMakeVisible (mixReadout);
    addAndMakeVisible (outputReadout);
    mix.onValueChange = [this] { updateReadouts(); };
    outputTrim.onValueChange = [this] { updateReadouts(); };
    updateReadouts();

    for (int i = 0; i < processor.getNumPrograms(); ++i)
        presetBox.addItem (processor.getProgramName (i), i + 1);
    presetBox.setTextWhenNothingSelected ("PRESETS");
    presetBox.setSelectedId (processor.getCurrentProgram() + 1, dontSendNotification);
    presetBox.setTooltip ("Factory presets: starting points, tuned for sources around 0 VU (-18 dBFS).");
    presetBox.onChange = [this]
    {
        const int idx = presetBox.getSelectedId() - 1;
        if (idx >= 0) { processor.setCurrentProgram (idx); processor.updateHostDisplay (AudioProcessorListener::ChangeDetails().withProgramChanged (true)); }
    };
    addAndMakeVisible (presetBox);

    advancedButton.setClickingTogglesState (false);
    advancedButton.setTooltip ("Input/wet trim, stereo link, detector HPF, colour, quality, mix law, listen, diagnostics.");
    advancedButton.onClick = [this] { setAdvancedVisible (! advanced.isVisible()); };
    addAndMakeVisible (advancedButton);
    advanced.onClose = [this] { setAdvancedVisible (false); };
    addChildComponent (advanced);
    setAdvancedVisible ((bool) s.state.getProperty (ChiocciaProcessor::uiAdvancedOpen, false));

    // Resizable with a fixed aspect ratio; everything is vector-drawn, so HiDPI is handled natively.
    const int storedWidth = (int) s.state.getProperty (ChiocciaProcessor::uiWidth, 1000);
    setResizable (true, true);
    setResizeLimits (700, (int) (700 * L::kHeight / L::kWidth), 2000, (int) (2000 * L::kHeight / L::kWidth));
    if (auto* c = getConstrainer()) c->setFixedAspectRatio (L::kWidth / L::kHeight);
    const int w = jlimit (700, 2000, storedWidth);
    setSize (w, roundToInt ((float) w * L::kHeight / L::kWidth));
}

ChiocciaEditor::~ChiocciaEditor()
{
    setLookAndFeel (nullptr);
}

void ChiocciaEditor::setAdvancedVisible (bool shouldBeVisible)
{
    advanced.setVisible (shouldBeVisible);
    if (shouldBeVisible) advanced.toFront (false);
    advancedButton.setToggleState (shouldBeVisible, dontSendNotification);
    processor.getState().state.setProperty (ChiocciaProcessor::uiAdvancedOpen, shouldBeVisible, nullptr);
}

void ChiocciaEditor::updateReadouts()
{
    mixReadout.setText ("MIX " + String (roundToInt (mix.getValue())) + " %");
    const double v = outputTrim.getValue();
    outputReadout.setText ((v > 0.0 ? "+" : "") + String (v, 1) + " dB");
}

void ChiocciaEditor::resized()
{
    const float s = (float) getWidth() / L::kWidth;
    auto R = [s] (const Rectangle<float>& r) { return (r * s).toNearestInt(); };

    facePlate.setBounds (getLocalBounds());
    gain.setBounds (R (L::gainKnob));
    peakReduction.setBounds (R (L::prKnob));
    outputTrim.setBounds (R (L::outputKnob));
    mix.setBounds (R (L::mix));
    mixReadout.setBounds (R (L::mixLabel));
    outputReadout.setBounds (R (L::outputValue));
    vu.setBounds (R (L::vu));
    vuMode.setBounds (R (L::vuMode));
    compLimit.setBounds (R (L::compSwitch));
    power.setBounds (R (L::powerSwitch));
    presetBox.setBounds (R (L::presetBox));
    advancedButton.setBounds (R (L::advancedButton));
    advanced.setBounds (R (L::advancedPanel));

    processor.getState().state.setProperty (ChiocciaProcessor::uiWidth, getWidth(), nullptr);
}
} // namespace chioccia
