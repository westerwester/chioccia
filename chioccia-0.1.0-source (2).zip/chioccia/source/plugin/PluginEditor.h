// Chioccia — plug-in editor (original code)
#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

#include "AdvancedPanel.h"
#include "ChiocciaLookAndFeel.h"
#include "FacePlate.h"
#include "PluginProcessor.h"
#include "VuMeter.h"

namespace chioccia
{
/** Text with a cartoon outline (used for the live MIX / OUTPUT read-outs). */
class OutlinedLabel final : public juce::Component
{
public:
    OutlinedLabel() { setInterceptsMouseClicks (false, false); }
    void setText (const juce::String& t) { if (t != text) { text = t; repaint(); } }
    void paint (juce::Graphics& g) override
    {
        ui::ChiocciaLookAndFeel::drawOutlinedText (g, text, getLocalBounds().toFloat(), (float) getHeight() * 0.85f,
                                                   ui::colours::ink, juce::Colours::white, (float) getHeight() * 0.22f);
    }
private:
    juce::String text;
};

class ChiocciaEditor final : public juce::AudioProcessorEditor
{
public:
    explicit ChiocciaEditor (ChiocciaProcessor&);
    ~ChiocciaEditor() override;

    void paint (juce::Graphics&) override {}
    void resized() override;

    /** Opens / closes the advanced panel (also stored in the session). */
    void setAdvancedVisible (bool shouldBeVisible);

private:
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;

    void updateReadouts();

    ChiocciaProcessor& processor;
    ui::ChiocciaLookAndFeel lnf;
    juce::TooltipWindow tooltips { this, 600 };

    ui::FacePlate facePlate;
    juce::Slider gain, peakReduction, outputTrim, mix;
    juce::ToggleButton compLimit, power, vuMode;
    std::unique_ptr<SliderAttachment> gainAtt, prAtt, outAtt, mixAtt;
    std::unique_ptr<ButtonAttachment> compAtt, powerAtt, vuAtt;
    OutlinedLabel mixReadout, outputReadout;
    ui::VuMeter vu;
    juce::ComboBox presetBox;
    juce::TextButton advancedButton { "ADVANCED" };
    ui::AdvancedPanel advanced;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ChiocciaEditor)
};
} // namespace chioccia
