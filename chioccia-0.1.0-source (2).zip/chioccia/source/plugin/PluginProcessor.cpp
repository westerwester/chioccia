// Chioccia — JUCE audio processor (original code)
#include "PluginProcessor.h"

#include "PluginEditor.h"
#include "Presets.h"

namespace chioccia
{
ChiocciaProcessor::ChiocciaProcessor()
    : AudioProcessor (BusesProperties()
                          .withInput ("Input", juce::AudioChannelSet::stereo(), true)
                          .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "ChiocciaState", params::createLayout()),
      reader (apvts)
{
    bypassParam = apvts.getParameter (params::id::bypass);
    apvts.state.setProperty (uiAdvancedOpen, false, nullptr);
    engine.setParameters (reader.read());
    setLatencySamples (engine.getLatencySamples());
}

bool ChiocciaProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    if (in != out) return false;
    return out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo();
}

void ChiocciaProcessor::prepareToPlay (double sampleRate, int)
{
    // All allocation happens here (message thread / host prepare), never in processBlock.
    engine.setParameters (reader.read());
    engine.prepare (sampleRate, juce::jmax (1, getTotalNumOutputChannels()));
    setLatencySamples (engine.getLatencySamples());
}

void ChiocciaProcessor::runEngine (juce::AudioBuffer<float>& buffer, bool forceBypass) noexcept
{
    juce::ScopedNoDenormals noDenormals;

    const int numIn = getTotalNumInputChannels();
    const int numOut = getTotalNumOutputChannels();
    const int numSamples = buffer.getNumSamples();
    for (int ch = numIn; ch < numOut; ++ch)
        buffer.clear (ch, 0, numSamples);

    auto p = reader.read();
    if (forceBypass) p.bypass = true;
    engine.setParameters (p);

    const int channels = juce::jmin (buffer.getNumChannels(), numOut, dsp::OptoEngine::kMaxChannels);
    engine.process (buffer.getArrayOfWritePointers(), channels, numSamples);
}

void ChiocciaProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    runEngine (buffer, false);
}

void ChiocciaProcessor::processBlockBypassed (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    // Host-side bypass without our parameter: keep running the engine with the bypass crossfade so the
    // output stays delayed by the reported latency (no time shift, no click) and states stay warm.
    runEngine (buffer, true);
}

juce::AudioProcessorEditor* ChiocciaProcessor::createEditor()
{
    return new ChiocciaEditor (*this);
}

int ChiocciaProcessor::getNumPrograms()
{
    return (int) presets::factory().size();
}

void ChiocciaProcessor::setCurrentProgram (int index)
{
    const auto& list = presets::factory();
    if (index < 0 || index >= (int) list.size()) return;
    currentProgram = index;
    presets::apply (list[(size_t) index], apvts);
}

const juce::String ChiocciaProcessor::getProgramName (int index)
{
    const auto& list = presets::factory();
    return (index >= 0 && index < (int) list.size()) ? juce::String (list[(size_t) index].name) : juce::String();
}

void ChiocciaProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    state.setProperty ("stateVersion", kStateVersion, nullptr);
    state.setProperty ("pluginVersion", CHIOCCIA_VERSION_STRING, nullptr);
    state.setProperty ("program", currentProgram, nullptr);
    if (auto xml = state.createXml())
        copyXmlToBinary (*xml, destData);
}

void ChiocciaProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    auto xml = getXmlFromBinary (data, sizeInBytes);
    if (xml == nullptr || ! xml->hasTagName (apvts.state.getType()))
        return;   // unknown / corrupted data: keep the current state

    auto tree = juce::ValueTree::fromXml (*xml);

    // Deterministic recall: parameters missing from an older session get their DEFAULT value
    // (APVTS alone would keep whatever value the instance currently has).
    for (auto* p : getParameters())
    {
        if (auto* rp = dynamic_cast<juce::RangedAudioParameter*> (p))
        {
            if (! tree.getChildWithProperty ("id", rp->paramID).isValid())
            {
                juce::ValueTree child ("PARAM");
                child.setProperty ("id", rp->paramID, nullptr);
                child.setProperty ("value", rp->convertFrom0to1 (rp->getDefaultValue()), nullptr);
                tree.appendChild (child, nullptr);
            }
        }
    }

    currentProgram = juce::jlimit (0, getNumPrograms() - 1, (int) tree.getProperty ("program", 0));
    apvts.replaceState (tree);

    // APVTS skips parameters whose *plain* value did not change, which can leave a non-canonical
    // normalised value (e.g. a bool at 0.12). Push the canonical value explicitly.
    for (auto* p : getParameters())
    {
        if (auto* rp = dynamic_cast<juce::RangedAudioParameter*> (p))
        {
            const auto child = apvts.state.getChildWithProperty ("id", rp->paramID);
            const float normalised = rp->convertTo0to1 ((float) child.getProperty ("value", rp->convertFrom0to1 (rp->getDefaultValue())));
            if (std::abs (rp->getValue() - normalised) > 1.0e-6f)
                rp->setValueNotifyingHost (normalised);
        }
    }
}
} // namespace chioccia

// Factory function required by the JUCE plug-in wrappers.
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new chioccia::ChiocciaProcessor();
}
