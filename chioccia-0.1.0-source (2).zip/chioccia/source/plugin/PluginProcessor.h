// Chioccia — JUCE audio processor (original code)
#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

#include "OptoEngine.h"
#include "Parameters.h"

namespace chioccia
{
inline constexpr const char* kPluginName = "Chioccia";
inline constexpr int kStateVersion = 1;

class ChiocciaProcessor final : public juce::AudioProcessor
{
public:
    ChiocciaProcessor();
    ~ChiocciaProcessor() override = default;

    // --- AudioProcessor ---------------------------------------------------------------------------
    void prepareToPlay (double sampleRate, int maximumExpectedSamplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    void processBlockBypassed (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    using AudioProcessor::processBlock;
    using AudioProcessor::processBlockBypassed;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return kPluginName; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override;
    int getCurrentProgram() override { return currentProgram; }
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    juce::AudioProcessorParameter* getBypassParameter() const override { return bypassParam; }

    // --- for the editor and tests ---------------------------------------------------------------
    juce::AudioProcessorValueTreeState& getState() noexcept { return apvts; }
    const dsp::OptoEngine& getEngine() const noexcept { return engine; }
    bool vuShowsOutput() const noexcept { return reader.vuShowsOutput(); }

    /** UI-only properties stored with the session (not automatable). */
    static inline const juce::Identifier uiAdvancedOpen { "uiAdvancedOpen" };
    static inline const juce::Identifier uiWidth { "uiWidth" };

private:
    void runEngine (juce::AudioBuffer<float>& buffer, bool forceBypass) noexcept;

    juce::AudioProcessorValueTreeState apvts;
    params::ParameterReader reader;
    juce::AudioProcessorParameter* bypassParam = nullptr;
    dsp::OptoEngine engine;
    int currentProgram = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ChiocciaProcessor)
};
} // namespace chioccia
