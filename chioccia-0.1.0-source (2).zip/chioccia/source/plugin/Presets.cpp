// Chioccia — factory presets (original code)
#include "Presets.h"

#include "Parameters.h"

namespace chioccia::presets
{
const std::vector<Preset>& factory()
{
    using namespace params::id;
    static const std::vector<Preset> list {
        { "Init", {} },
        { "Vocal - Smooth Leveling",
          { { peakReduction, 52.0f }, { gain, 62.0f }, { colour, 45.0f }, { scHpfOn, 1.0f }, { scHpfFreq, 80.0f } } },
        { "Bass - Even Sustain",
          { { peakReduction, 58.0f }, { gain, 65.0f }, { colour, 60.0f }, { scHpfOn, 0.0f } } },
        { "Drums - Parallel Smash",
          { { peakReduction, 82.0f }, { gain, 76.0f }, { compLimit, 1.0f }, { mix, 35.0f }, { colour, 70.0f },
            { scHpfOn, 1.0f }, { scHpfFreq, 60.0f }, { quality, 2.0f } } },
        { "Gentle Glue",
          { { peakReduction, 38.0f }, { gain, 53.0f }, { colour, 35.0f } } },
        { "Parallel Bus (100% Wet)",
          { { peakReduction, 75.0f }, { gain, 72.0f }, { compLimit, 1.0f }, { mix, 100.0f }, { colour, 60.0f } } },
    };
    return list;
}

void apply (const Preset& preset, juce::AudioProcessorValueTreeState& apvts)
{
    for (const auto& pidString : params::allIds())
    {
        if (pidString == params::id::bypass || pidString == params::id::vuMode)
            continue;   // presets never change bypass or the meter view

        auto* param = apvts.getParameter (pidString);
        if (param == nullptr) continue;

        float normalised = param->getDefaultValue();
        for (const auto& [name, value] : preset.values)
            if (pidString == name)
                normalised = param->convertTo0to1 (value);

        param->beginChangeGesture();
        param->setValueNotifyingHost (normalised);
        param->endChangeGesture();
    }
}
} // namespace chioccia::presets
