// Chioccia — factory presets (original code). Starting points, not "finished" settings:
// gain-reduction depends on the level of the source (calibrated for material around 0 VU = −18 dBFS).
#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

namespace chioccia::presets
{
struct Preset
{
    const char* name;
    std::vector<std::pair<const char*, float>> values;   // parameter id → plain value; others = default
};

const std::vector<Preset>& factory();

/** Sets every parameter: listed ones to the preset value, all others to their default. */
void apply (const Preset& preset, juce::AudioProcessorValueTreeState& apvts);
} // namespace chioccia::presets
