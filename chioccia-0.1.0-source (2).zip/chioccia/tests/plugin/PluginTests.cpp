// Chioccia — tests of the JUCE plug-in layer (original code)
// Usage: ChiocciaPluginTests [--snapshots <dir>]
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_gui_basics/juce_gui_basics.h>

#include <iostream>

#include "Parameters.h"
#include "PluginEditor.h"
#include "PluginProcessor.h"
#include "Presets.h"

using namespace juce;
using chioccia::ChiocciaProcessor;

namespace
{
int failures = 0, checks = 0;
String current;
#define CHECK(cond, msg) do { ++checks; if (! (cond)) { ++failures; std::cout << "  FAIL [" << current << "] " << msg << "\n"; } } while (0)
void report (const String& s) { std::cout << "  · " << s << "\n"; }

float plainValue (ChiocciaProcessor& p, const String& pid)
{
    return p.getState().getRawParameterValue (pid)->load();
}

void setPlain (ChiocciaProcessor& p, const String& pid, float v)
{
    auto* param = p.getState().getParameter (pid);
    param->setValueNotifyingHost (param->convertTo0to1 (v));
}

void fillTone (AudioBuffer<float>& b, double sr, float rmsDb, int offset)
{
    const float a = std::sqrt (2.0f) * Decibels::decibelsToGain (rmsDb);
    for (int ch = 0; ch < b.getNumChannels(); ++ch)
        for (int i = 0; i < b.getNumSamples(); ++i)
            b.setSample (ch, i, a * (float) std::sin (2.0 * MathConstants<double>::pi * 220.0 * (offset + i) / sr)
                                + 0.5f * a * (float) std::sin (2.0 * MathConstants<double>::pi * 2750.0 * (offset + i) / sr));
}

void testParameterIds()
{
    current = "parameter_ids";
    const StringArray expected { "peakReduction", "gain", "compLimit", "mix", "outputTrim", "vuMode", "bypass",
                                 "inputTrim", "wetTrim", "stereoLink", "scHpfOn", "scHpfFreq", "colour", "quality",
                                 "compare", "noise", "humFreq", "mixLaw", "listen", "diagnostic" };
    CHECK (chioccia::params::allIds() == expected, "parameter IDs changed: sessions/automation would break");
    ChiocciaProcessor p;
    CHECK (p.getParameters().size() == expected.size(), "parameter count");
    for (auto& id : expected)
    {
        auto* param = dynamic_cast<RangedAudioParameter*> (p.getState().getParameter (id));
        CHECK (param != nullptr, "missing parameter " << id);
        if (param != nullptr) CHECK (param->getVersionHint() == 1, "version hint of " << id);
    }
    CHECK (p.getBypassParameter() == p.getState().getParameter ("bypass"), "host bypass mapped to our bypass parameter");
}

void testBusLayouts()
{
    current = "bus_layouts";
    ChiocciaProcessor p;
    auto layout = [] (AudioChannelSet in, AudioChannelSet out)
    {
        AudioProcessor::BusesLayout l;
        l.inputBuses.add (in);
        l.outputBuses.add (out);
        return l;
    };
    CHECK (p.checkBusesLayoutSupported (layout (AudioChannelSet::mono(), AudioChannelSet::mono())), "mono");
    CHECK (p.checkBusesLayoutSupported (layout (AudioChannelSet::stereo(), AudioChannelSet::stereo())), "stereo");
    CHECK (! p.checkBusesLayoutSupported (layout (AudioChannelSet::mono(), AudioChannelSet::stereo())), "mono->stereo must be rejected");
    CHECK (! p.checkBusesLayoutSupported (layout (AudioChannelSet::create5point1(), AudioChannelSet::create5point1())), "5.1 must be rejected");
}

void testLatencyAndProcessing()
{
    current = "latency_processing";
    for (double sr : { 44100.0, 48000.0, 88200.0, 96000.0, 176400.0, 192000.0 })
    {
        for (int channels : { 1, 2 })
        {
            ChiocciaProcessor p;
            p.setPlayConfigDetails (channels, channels, sr, 512);
            p.prepareToPlay (sr, 512);
            CHECK (p.getLatencySamples() == p.getEngine().getLatencySamples(), "latency reported to host");
            MidiBuffer midi;
            bool finite = true;
            int pos = 0;
            for (int bs : { 512, 1, 13, 4096, 0, 511, 2048 })   // includes blocks larger than announced
            {
                AudioBuffer<float> b (channels, std::max (bs, 1));
                b.clear();
                if (bs > 0) fillTone (b, sr, -12.0f, pos);
                AudioBuffer<float> view (b.getArrayOfWritePointers(), channels, bs);
                p.processBlock (view, midi);
                for (int ch = 0; ch < channels; ++ch)
                    for (int i = 0; i < bs; ++i) finite = finite && std::isfinite (view.getSample (ch, i));
                pos += bs;
            }
            CHECK (finite, "non-finite output at " << sr << " Hz, " << channels << " ch");
        }
        ChiocciaProcessor probe;
        probe.prepareToPlay (sr, 256);
        report ("latency at " + String ((int) sr) + " Hz: " + String (probe.getLatencySamples()) + " samples = "
                + String (1000.0 * probe.getLatencySamples() / sr, 3) + " ms (all quality modes)");
    }
}

void testStateRoundTrip()
{
    current = "state";
    ChiocciaProcessor a;
    Random rng (42);
    for (auto* param : a.getParameters())
        param->setValueNotifyingHost (rng.nextFloat());
    a.getState().state.setProperty (ChiocciaProcessor::uiAdvancedOpen, true, nullptr);
    MemoryBlock mb;
    a.getStateInformation (mb);

    ChiocciaProcessor b;
    b.setStateInformation (mb.getData(), (int) mb.getSize());
    for (auto& id : chioccia::params::allIds())
        CHECK (std::abs (plainValue (a, id) - plainValue (b, id)) < 1e-4f, "round trip of " << id << ": " << plainValue (a, id) << " vs " << plainValue (b, id));
    CHECK ((bool) b.getState().state.getProperty (ChiocciaProcessor::uiAdvancedOpen) == true, "UI state restored");

    // Older session without some parameters: they must come back at their defaults.
    auto xml = AudioProcessor::getXmlFromBinary (mb.getData(), (int) mb.getSize());
    for (auto* e : xml->getChildWithTagNameIterator ("PARAM"))
        if (e->getStringAttribute ("id") == "colour") { xml->removeChildElement (e, true); break; }
    MemoryBlock old;
    AudioProcessor::copyXmlToBinary (*xml, old);
    ChiocciaProcessor c;
    setPlain (c, "colour", 90.0f);
    c.setStateInformation (old.getData(), (int) old.getSize());
    CHECK (std::abs (plainValue (c, "colour") - 50.0f) < 1e-4f, "missing parameter must load its default, got " << plainValue (c, "colour"));
    CHECK (std::abs (plainValue (c, "gain") - plainValue (a, "gain")) < 1e-4f, "other values still restored");

    // Garbage must be ignored without changing anything.
    ChiocciaProcessor d;
    setPlain (d, "peakReduction", 77.0f);
    const char garbage[] = "this is not a plugin state";
    d.setStateInformation (garbage, (int) sizeof (garbage));
    CHECK (std::abs (plainValue (d, "peakReduction") - 77.0f) < 1e-4f, "garbage state changed parameters");
}

void testPresets()
{
    current = "presets";
    ChiocciaProcessor p;
    p.setPlayConfigDetails (2, 2, 48000.0, 512);
    p.prepareToPlay (48000.0, 512);
    const auto& list = chioccia::presets::factory();
    CHECK (p.getNumPrograms() == (int) list.size(), "program count");
    for (int i = 0; i < (int) list.size(); ++i)
    {
        p.setCurrentProgram (i);
        CHECK (p.getCurrentProgram() == i, "current program");
        for (auto& [pid, value] : list[(size_t) i].values)
            CHECK (std::abs (plainValue (p, pid) - value) < 0.11f, list[(size_t) i].name << ": " << pid << " = " << plainValue (p, pid));

        // Measure what the preset does on a test signal at 0 VU (documentation numbers, not targets).
        ChiocciaProcessor q;
        q.setPlayConfigDetails (2, 2, 48000.0, 512);
        q.setCurrentProgram (i);
        q.prepareToPlay (48000.0, 512);
        MidiBuffer midi;
        float minGr = 0.0f;
        double inSum = 0.0, outSum = 0.0;
        for (int blk = 0; blk < 48000 * 4 / 512; ++blk)
        {
            AudioBuffer<float> b (2, 512);
            fillTone (b, 48000.0, -18.0f, blk * 512);
            if (blk >= 48000 * 3 / 512) for (int k = 0; k < 512; ++k) inSum += (double) b.getSample (0, k) * b.getSample (0, k);
            q.processBlock (b, midi);
            if (blk >= 48000 * 3 / 512)
            {
                for (int k = 0; k < 512; ++k) outSum += (double) b.getSample (0, k) * b.getSample (0, k);
                minGr = std::max (minGr, q.getEngine().getGainReductionDb());
            }
        }
        report (String (list[(size_t) i].name) + ": GR peak " + String (minGr, 1) + " dB, output/input "
                + String (10.0 * std::log10 (outSum / inSum), 1) + " dB  (two-tone 220 Hz + 2.75 kHz at -18 dBFS RMS)");
    }
}

void testHostBypass()
{
    current = "host_bypass";
    ChiocciaProcessor p;
    p.setPlayConfigDetails (2, 2, 48000.0, 256);
    setPlain (p, "peakReduction", 90.0f);
    setPlain (p, "gain", 80.0f);
    p.prepareToPlay (48000.0, 256);
    MidiBuffer midi;
    const int L = p.getLatencySamples();
    std::vector<float> in, out;
    for (int blk = 0; blk < 40; ++blk)
    {
        AudioBuffer<float> b (2, 256);
        fillTone (b, 48000.0, -10.0f, blk * 256);
        for (int k = 0; k < 256; ++k) in.push_back (b.getSample (0, k));
        p.processBlockBypassed (b, midi);
        for (int k = 0; k < 256; ++k) out.push_back (b.getSample (0, k));
    }
    double maxErr = 0.0;
    for (size_t i = 4800; i < out.size(); ++i) maxErr = std::max (maxErr, (double) std::abs (out[i] - in[i - (size_t) L]));
    CHECK (maxErr <= 0.0, "host bypass must equal the input delayed by the reported latency, err " << maxErr);
}

void testEditorAndSnapshots (const File& dir)
{
    current = "editor";
    ChiocciaProcessor p;
    p.setPlayConfigDetails (2, 2, 48000.0, 512);
    p.prepareToPlay (48000.0, 512);
    std::unique_ptr<AudioProcessorEditor> ed (p.createEditor());
    CHECK (ed != nullptr, "editor");
    if (ed == nullptr) return;
    CHECK (ed->getWidth() == 1000 && ed->getHeight() == 340, "default editor size " << ed->getWidth() << "x" << ed->getHeight());
    CHECK (ed->isResizable(), "editor resizable");

    auto* editor = dynamic_cast<chioccia::ChiocciaEditor*> (ed.get());
    for (auto [width, advancedOpen, name] : { std::tuple { 1000, false, "gui_1000.png" }, std::tuple { 1600, false, "gui_1600_hidpi.png" },
                                              std::tuple { 1000, true, "gui_advanced.png" }, std::tuple { 700, false, "gui_700_min.png" } })
    {
        ed->setSize (width, roundToInt (width * 0.34f));
        editor->setAdvancedVisible (advancedOpen);
        auto img = ed->createComponentSnapshot (ed->getLocalBounds(), true, 1.0f);
        CHECK (img.isValid() && img.getWidth() == width, "snapshot " << name);
        if (dir != File())
        {
            dir.createDirectory();
            auto f = dir.getChildFile (name);
            f.deleteFile();
            FileOutputStream os (f);
            PNGImageFormat png;
            CHECK (os.openedOk() && png.writeImageToStream (img, os), "writing " << name);
        }
    }
    // A 2x scaled render of the default size, as a HiDPI display would see it.
    ed->setSize (1000, 340);
    editor->setAdvancedVisible (false);
    auto hidpi = ed->createComponentSnapshot (ed->getLocalBounds(), true, 2.0f);
    CHECK (hidpi.getWidth() == 2000, "HiDPI snapshot width " << hidpi.getWidth());
    if (dir != File())
    {
        auto f = dir.getChildFile ("gui_1000_at_2x.png");
        f.deleteFile();
        FileOutputStream os (f);
        PNGImageFormat().writeImageToStream (hidpi, os);
    }
    ed.reset();
}
} // namespace

int main (int argc, char** argv)
{
    ScopedJuceInitialiser_GUI juceInit;
    File snapshotDir;
    for (int i = 1; i + 1 < argc; ++i)
        if (String (argv[i]) == "--snapshots") snapshotDir = File::getCurrentWorkingDirectory().getChildFile (argv[i + 1]);

    std::cout << "Chioccia plug-in tests\n";
    testParameterIds();
    testBusLayouts();
    testLatencyAndProcessing();
    testStateRoundTrip();
    testPresets();
    testHostBypass();
    testEditorAndSnapshots (snapshotDir);
    std::cout << (failures == 0 ? "ALL PASSED" : "FAILURES") << " — " << checks << " checks, " << failures << " failed\n";
    return failures == 0 ? 0 : 1;
}
