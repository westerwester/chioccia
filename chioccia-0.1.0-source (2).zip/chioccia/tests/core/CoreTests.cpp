// Chioccia — automatic tests of the JUCE-independent DSP core (original code)
// Build target: chioccia_core_tests (ctest name: core_tests). Exit code != 0 on any failure.
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <sstream>

#include "TestUtils.h"

using namespace chioccia;
using namespace chioccia::testutil;
using dsp::EngineParameters;
using dsp::OptoEngine;

namespace
{
int failures = 0, checks = 0;
std::string currentTest;

#define CHECK(cond, msg)                                                                                  \
    do {                                                                                                  \
        ++checks;                                                                                         \
        if (! (cond)) { ++failures; std::cout << "  FAIL [" << currentTest << "] " << msg << "\n"; }       \
    } while (0)

void report (const std::string& what) { std::cout << "  · " << what << "\n"; }

EngineParameters neutral()
{
    EngineParameters p;
    p.peakReduction = 0.0f; p.gain = 50.0f; p.colourPercent = 0.0f; p.mixPercent = 100.0f;
    return p;
}

Buffer multiTone (double fs, int n, double levelDb)
{
    Buffer b ((size_t) n, 0.0f);
    const double freqs[] = { 60.0, 440.0, 1000.0, 3150.0, 8000.0, 15000.0 };
    const double a = dbfsToPeak (levelDb) / 6.0;
    for (int i = 0; i < n; ++i)
        for (double f : freqs) b[(size_t) i] += (float) (a * std::sin (2.0 * kPi * f * i / fs + f));
    return b;
}

// ------------------------------------------------------------------------------------------------
void testHalfBandDesign()
{
    currentTest = "halfband_design";
    for (int taps : { OptoEngine::kStage1Taps, OptoEngine::kStage2Taps })
    {
        const auto h = dsp::designHalfBand (taps, OptoEngine::kStopbandDb);
        const int c = (taps - 1) / 2;
        double sum = 0.0, asym = 0.0, evenZero = 0.0;
        for (int i = 0; i < taps; ++i)
        {
            sum += h[(size_t) i];
            asym = std::max (asym, std::abs (h[(size_t) i] - h[(size_t) (taps - 1 - i)]));
            if (i != c && ((i - c) % 2 == 0)) evenZero = std::max (evenZero, std::abs (h[(size_t) i]));
        }
        CHECK (std::abs (sum - 1.0) < 1e-12, "DC gain " << sum);
        CHECK (asym < 1e-15, "not symmetric (linear phase)");
        CHECK (evenZero == 0.0, "half-band zeros not exact");
        CHECK (std::abs (h[(size_t) c] - 0.5) < 1e-15, "centre tap");
    }
}

void testOversamplerLatencyAndPassband()
{
    currentTest = "oversampler";
    const auto h1 = dsp::designHalfBand (OptoEngine::kStage1Taps, OptoEngine::kStopbandDb);
    const auto h2 = dsp::designHalfBand (OptoEngine::kStage2Taps, OptoEngine::kStopbandDb);
    for (int factor : { 1, 2, 4 })
    {
        dsp::Oversampler os;
        os.prepare (factor, h1, h2);
        const int L = os.getLatency();

        // Impulse: peak must land exactly on the reported latency.
        int peakIdx = -1; float peak = 0.0f;
        for (int i = 0; i < 400; ++i)
        {
            const float y = os.process (i == 0 ? 1.0f : 0.0f, [] (float s) { return s; });
            if (std::abs (y) > peak) { peak = std::abs (y); peakIdx = i; }
        }
        CHECK (peakIdx == L, "factor " << factor << " impulse peak at " << peakIdx << " but latency " << L);

        // Passband: tones up to 0.40 fs must come back delayed by L with tiny error.
        const double fs = 48000.0;
        for (double f : { 100.0, 1000.0, 10000.0, 19200.0 })
        {
            os.reset();
            const int n = 9600;
            auto x = sine (fs, f, 0.5, n);
            Buffer y ((size_t) n);
            for (int i = 0; i < n; ++i) y[(size_t) i] = os.process (x[(size_t) i], [] (float s) { return s; });
            const auto ref = delayed (x, L);
            double errPow = 0.0, refPow = 0.0;
            for (int i = 2000; i < n; ++i) { const double d = y[(size_t) i] - ref[(size_t) i]; errPow += d * d; refPow += ref[(size_t) i] * ref[(size_t) i]; }
            const double errDb = 10.0 * std::log10 (errPow / refPow + 1e-30);
            CHECK (errDb < -80.0, "factor " << factor << " f=" << f << " residual " << errDb << " dB");
            if (f == 19200.0) report ("OS x" + std::to_string (factor) + " residual @19.2k/48k: " + std::to_string (errDb) + " dB");
        }
    }
}

void testReportedLatencyAndNull()
{
    currentTest = "null_and_latency";
    for (double fs : { 44100.0, 48000.0, 88200.0, 96000.0, 176400.0, 192000.0 })
    {
        for (auto q : { dsp::Quality::x1, dsp::Quality::x2, dsp::Quality::x4 })
        {
            OptoEngine e;
            auto p = neutral();
            p.quality = q;
            p.diagnostic = dsp::Diagnostic::nullResidual;
            e.setParameters (p);
            e.prepare (fs, 2);
            const int n = (int) fs;  // 1 s
            auto in = multiTone (fs, n, -6.0);
            auto out = run (e, in, in, 256);
            const double resDb = rmsDb (out.l, (size_t) (0.1 * fs));
            const double limit = (q == dsp::Quality::x1) ? -200.0 : -80.0;
            CHECK (resDb < limit, "fs=" << fs << " q=" << (int) q << " null residual " << resDb << " dBFS");
            if (fs == 48000.0 || fs == 44100.0)
                report ("null residual fs=" + std::to_string ((int) fs) + " q=" + std::to_string ((int) q) + ": " + std::to_string (resDb) + " dBFS (test tones ≤ 15 kHz)");
            CHECK (e.getLatencySamples() == e.getPathLatency (dsp::Quality::x4), "constant latency");
        }
    }
}

void testImpulseAlignment()
{
    currentTest = "impulse_alignment";
    for (auto mix : { 0.0f, 50.0f, 100.0f })
    {
        OptoEngine e;
        auto p = neutral();
        p.mixPercent = mix;
        p.quality = dsp::Quality::x4;
        e.setParameters (p);
        e.prepare (48000.0, 1);
        Buffer x (1000, 0.0f);
        x[10] = 0.5f;
        auto out = run (e, x, {}, 64);
        size_t peakIdx = 0;
        for (size_t i = 0; i < out.l.size(); ++i) if (std::abs (out.l[i]) > std::abs (out.l[peakIdx])) peakIdx = i;
        CHECK ((int) peakIdx == 10 + e.getLatencySamples(), "mix " << mix << " peak at " << peakIdx);
        // A band-limited (linear-phase) impulse peaks slightly below the input value: ±2 % allowed.
        CHECK (std::abs (out.l[peakIdx] - 0.5f) < 0.01f, "mix " << mix << " peak value " << out.l[peakIdx]);
        if (mix == 100.0f) report ("4x wet impulse peak " + std::to_string (out.l[peakIdx]) + " for input 0.5 (band-limiting, not a delay error)");
    }
}

void testDryPathIsClean()
{
    currentTest = "dry_clean";
    OptoEngine e;
    EngineParameters p;
    p.peakReduction = 100.0f; p.gain = 90.0f; p.colourPercent = 100.0f; p.mixPercent = 0.0f; p.limitMode = true;
    p.noisePercent = 100.0f;
    e.setParameters (p);
    e.prepare (48000.0, 2);
    auto in = multiTone (48000.0, 48000, -3.0);
    auto out = run (e, in, in, 512);
    const auto ref = delayed (in, e.getLatencySamples());
    CHECK (maxAbsDiff (out.l, ref) == 0.0, "mix 0 must be bit-identical to the delayed input");
    CHECK (maxAbsDiff (out.r, ref) == 0.0, "mix 0 (R)");
}

void testMixLinearity()
{
    currentTest = "mix_law";
    const double fs = 48000.0;
    auto in = multiTone (fs, 48000, -10.0);
    auto render = [&] (float mix, dsp::Listen listen, dsp::MixLaw law)
    {
        OptoEngine e;
        EngineParameters p;
        p.peakReduction = 60.0f; p.gain = 60.0f; p.mixPercent = mix; p.listen = listen; p.mixLaw = law;
        e.setParameters (p);
        e.prepare (fs, 1);
        return run (e, in, {}, 128).l;
    };
    const auto dry = render (0.0f, dsp::Listen::dryOnly, dsp::MixLaw::linearCrossfade);
    const auto wet = render (100.0f, dsp::Listen::wetOnly, dsp::MixLaw::linearCrossfade);
    const auto wet100 = render (100.0f, dsp::Listen::mix, dsp::MixLaw::linearCrossfade);
    CHECK (maxAbsDiff (wet, wet100) == 0.0, "mix 100 % == wet only");
    for (float m : { 25.0f, 50.0f, 75.0f })
    {
        const auto mixed = render (m, dsp::Listen::mix, dsp::MixLaw::linearCrossfade);
        Buffer expect (in.size());
        for (size_t i = 0; i < in.size(); ++i) expect[i] = (1.0f - m / 100.0f) * dry[i] + (m / 100.0f) * wet[i];
        CHECK (maxAbsDiff (mixed, expect) < 1e-6, "linear crossfade at " << m << " %");
        const auto additive = render (m, dsp::Listen::mix, dsp::MixLaw::dryConstant);
        for (size_t i = 0; i < in.size(); ++i) expect[i] = dry[i] + (m / 100.0f) * wet[i];
        CHECK (maxAbsDiff (additive, expect) < 1e-6, "dry-constant law at " << m << " %");
    }
}

void testBlockSizeInvariance()
{
    currentTest = "block_size_invariance";
    const double fs = 44100.0;
    auto in = multiTone (fs, 3 * 44100, -4.0);
    Buffer inR = in;
    for (auto& s : inR) s *= 0.7f;
    auto render = [&] (int bs, bool random)
    {
        OptoEngine e;
        EngineParameters p;
        p.peakReduction = 70.0f; p.gain = 65.0f; p.mixPercent = 60.0f; p.stereoLinkPercent = 50.0f;
        p.quality = dsp::Quality::x4;
        e.setParameters (p);
        e.prepare (fs, 2);
        std::mt19937 rng (1234);
        return run (e, in, inR, bs, {}, random ? &rng : nullptr);
    };
    const auto a = render (512, false), b = render (1, false), c = render (0, true);
    CHECK (maxAbsDiff (a.l, b.l) == 0.0 && maxAbsDiff (a.r, b.r) == 0.0, "block 512 vs 1");
    CHECK (maxAbsDiff (a.l, c.l) == 0.0 && maxAbsDiff (a.r, c.r) == 0.0, "block 512 vs random 1..2048");
}

void testRobustness()
{
    currentTest = "robustness";
    OptoEngine e;
    EngineParameters p;
    p.peakReduction = 80.0f; p.colourPercent = 100.0f; p.quality = dsp::Quality::x4;
    e.setParameters (p);
    e.prepare (96000.0, 2);
    Buffer bad (9600, 0.0f);
    for (size_t i = 0; i < bad.size(); ++i)
    {
        switch (i % 7)
        {
            case 0: bad[i] = std::numeric_limits<float>::quiet_NaN(); break;
            case 1: bad[i] = std::numeric_limits<float>::infinity(); break;
            case 2: bad[i] = -std::numeric_limits<float>::infinity(); break;
            case 3: bad[i] = 1.0e30f; break;
            case 4: bad[i] = -1.0e30f; break;
            case 5: bad[i] = 1.0e-40f; break;   // denormal
            default: bad[i] = 0.5f; break;
        }
    }
    auto out = run (e, bad, bad, 333);
    bool finite = true;
    for (float v : out.l) finite = finite && std::isfinite (v);
    for (float v : out.r) finite = finite && std::isfinite (v);
    CHECK (finite, "outputs must stay finite with NaN/Inf/huge input");

    // After the abuse the engine must behave like a fresh instance again (no stuck state).
    auto tone = sine (96000.0, 1000.0, 0.1, 96000 * 25);
    auto out2 = run (e, tone, tone, 512);
    OptoEngine fresh;
    fresh.setParameters (p);
    fresh.prepare (96000.0, 2);
    auto ref = run (fresh, tone, tone, 512);
    const double lvl8 = rmsDb (out2.l, 96000 * 8, 96000 * 10), ref8 = rmsDb (ref.l, 96000 * 8, 96000 * 10);
    const double lvl = rmsDb (out2.l, 96000 * 23), lvlRef = rmsDb (ref.l, 96000 * 23);
    report ("after 0.1 s of NaN/Inf/±1e30 input: level at 8-10 s " + std::to_string (lvl8 - ref8) + " dB vs fresh, at 23-25 s "
            + std::to_string (lvl - lvlRef) + " dB (opto memory recovering)");
    CHECK (std::isfinite (lvl) && std::abs (lvl - lvlRef) < 0.5, "recovers after abuse, level " << lvl << " vs " << lvlRef);

    // Long silence: output exactly zero (no noise), no denormals.
    Buffer silence (96000 * 12, 0.0f);
    auto out3 = run (e, silence, silence, 1024);
    bool clean = true;
    for (size_t i = 96000 * 6; i < out3.l.size(); ++i) clean = clean && (out3.l[i] == 0.0f || std::abs (out3.l[i]) > 1.0e-30f);
    CHECK (clean, "denormals in silence tail");
    double tailMax = 0.0;
    for (size_t i = 96000 * 6; i < out3.l.size(); ++i) tailMax = std::max (tailMax, (double) std::abs (out3.l[i]));
    CHECK (tailMax < 1e-12, "silence must stay silent, got " << tailMax);
}

void testStereoLink()
{
    currentTest = "stereo_link";
    const double fs = 48000.0;
    auto l = sine (fs, 997.0, 0.4, 96000);
    Buffer r (l);
    for (auto& s : r) s *= 0.25f;   // -12 dB right channel
    OptoEngine e;
    EngineParameters p;
    p.peakReduction = 75.0f; p.stereoLinkPercent = 100.0f; p.colourPercent = 0.0f; p.quality = dsp::Quality::x1;
    e.setParameters (p);
    e.prepare (fs, 2);
    auto out = run (e, l, r, 256);
    double maxRatioErr = 0.0;
    for (size_t i = 10000; i < out.l.size(); ++i)
        if (std::abs (out.l[i]) > 1e-3f) maxRatioErr = std::max (maxRatioErr, (double) std::abs (out.r[i] / out.l[i] - 0.25f));
    CHECK (maxRatioErr < 1e-5, "100 % link must keep L/R ratio, err " << maxRatioErr);

    // Identical inputs with link 0 → identical outputs.
    OptoEngine e2;
    p.stereoLinkPercent = 0.0f;
    e2.setParameters (p);
    e2.prepare (fs, 2);
    auto out2 = run (e2, l, l, 256);
    CHECK (maxAbsDiff (out2.l, out2.r) == 0.0, "unlinked identical channels");

    // Unlinked: the quieter channel must get less gain reduction than the louder one.
    const double grL = rmsDb (out2.l, 48000) - rmsDb (l, 48000);
    OptoEngine e3;
    e3.setParameters (p);
    e3.prepare (fs, 2);
    auto out3 = run (e3, l, r, 256);
    const double grR = rmsDb (out3.r, 48000) - rmsDb (r, 48000);
    CHECK (grR > grL + 3.0, "unlinked quiet channel should be compressed less (" << grL << " vs " << grR << ")");
}

void testQualitySwitching()
{
    currentTest = "quality_switch";
    const double fs = 48000.0;
    auto in = multiTone (fs, 4 * 48000, -8.0);
    for (float colour : { 0.0f, 60.0f })
    {
        auto render = [&] (bool switching)
        {
            OptoEngine e;
            EngineParameters p;
            p.peakReduction = 50.0f; p.colourPercent = colour; p.quality = dsp::Quality::x2;
            e.setParameters (p);
            e.prepare (fs, 1);
            int lastLatency = e.getLatencySamples();
            bool latencyStable = true;
            auto out = run (e, in, {}, 480, [&] (int pos)
            {
                if (! switching) return;
                if (pos == 48000)  { p.quality = dsp::Quality::x4; e.setParameters (p); }
                if (pos == 96000)  { p.quality = dsp::Quality::x1; e.setParameters (p); }
                if (pos == 144000) { p.quality = dsp::Quality::x2; e.setParameters (p); }
                latencyStable = latencyStable && e.getLatencySamples() == lastLatency;
            });
            CHECK (latencyStable, "latency must not change when switching quality");
            return out.l;
        };
        const auto ref = render (false), sw = render (true);
        double errPow = 0.0, refPow = 0.0;
        for (size_t i = 24000; i < ref.size(); ++i) { const double d = sw[i] - ref[i]; errPow += d * d; refPow += (double) ref[i] * ref[i]; }
        const double errDb = 10.0 * std::log10 (errPow / refPow + 1e-30);
        // Largest sample-to-sample step of the difference signal: detects clicks at the switch points.
        double maxStep = 0.0;
        for (size_t i = 24001; i < ref.size(); ++i) maxStep = std::max (maxStep, (double) std::abs ((sw[i] - ref[i]) - (sw[i - 1] - ref[i - 1])));
        report ("colour " + std::to_string ((int) colour) + "%: switched vs constant-quality difference " + std::to_string (errDb)
                + " dB, max diff step " + std::to_string (20.0 * std::log10 (maxStep + 1e-30)) + " dBFS");
        CHECK (errDb < (colour == 0.0f ? -80.0 : -40.0), "switched render deviates too much: " << errDb << " dB");
    }
}

void testBypass()
{
    currentTest = "bypass";
    OptoEngine e;
    EngineParameters p;
    p.peakReduction = 90.0f; p.gain = 80.0f; p.bypass = true;
    e.setParameters (p);
    e.prepare (48000.0, 2);
    auto in = multiTone (48000.0, 48000, -6.0);
    auto out = run (e, in, in, 100);
    CHECK (maxAbsDiff (out.l, delayed (in, e.getLatencySamples())) == 0.0, "bypass == input delayed by the reported latency");
}

void testZeroPeakReduction()
{
    currentTest = "pr_zero";
    OptoEngine e;
    auto p = neutral();
    p.quality = dsp::Quality::x1;
    e.setParameters (p);
    e.prepare (48000.0, 1);
    auto in = multiTone (48000.0, 48000, 0.0);
    auto out = run (e, in, {}, 64);
    CHECK (e.getGainReductionDb() == 0.0f, "PR 0 must not reduce gain");
    CHECK (maxAbsDiff (out.l, delayed (in, e.getLatencySamples())) == 0.0, "PR 0, colour 0, gain 50: wet path transparent");
}

void testSmoothing()
{
    currentTest = "smoothing";
    OptoEngine e;
    auto p = neutral();
    p.quality = dsp::Quality::x1;
    e.setParameters (p);
    e.prepare (48000.0, 1);
    Buffer dc (48000, 0.25f);
    auto out = run (e, dc, {}, 64, [&] (int pos) { if (pos == 24000) { p.gain = 100.0f; p.outputTrimDb = -12.0f; e.setParameters (p); } });
    double maxStep = 0.0;
    for (size_t i = 1000; i < out.l.size(); ++i) maxStep = std::max (maxStep, (double) std::abs (out.l[i] - out.l[i - 1]));
    // A +30 dB / -12 dB jump of the target must be spread over ~20 ms.
    CHECK (maxStep < 0.01, "gain change not smoothed, max step " << maxStep);
}

void testCompareMode()
{
    currentTest = "compare";
    OptoEngine e;
    EngineParameters p;
    p.peakReduction = 60.0f; p.gain = 75.0f; p.outputTrimDb = 9.0f; p.levelMatchedCompare = true;
    e.setParameters (p);
    e.prepare (48000.0, 2);
    auto in = multiTone (48000.0, 48000 * 12, -14.0);
    auto out = run (e, in, in, 512);
    const double diff = rmsDb (out.l, 48000 * 8) - rmsDb (in, 48000 * 8);
    CHECK (std::abs (diff) < 1.0, "level-matched compare should match input loudness, diff " << diff << " dB");
}

void testMonoAndGainReductionSanity()
{
    currentTest = "gr_sanity";
    for (double fs : { 44100.0, 48000.0, 96000.0, 192000.0 })
    {
        OptoEngine e;
        EngineParameters p;
        p.peakReduction = 60.0f; p.colourPercent = 0.0f;
        e.setParameters (p);
        e.prepare (fs, 1);
        auto in = sine (fs, 1000.0, rmsDbToSinePeak (-18.0), (int) (3 * fs));
        auto out = run (e, in, {}, 512);
        const double gr = rmsDb (in, (size_t) (2 * fs)) - rmsDb (out.l, (size_t) (2 * fs));
        report ("fs " + std::to_string ((int) fs) + ": 1 kHz @ 0 VU, PR 60 → GR " + std::to_string (gr) + " dB");
        static double ref = gr;
        CHECK (gr > 2.0 && gr < 20.0, "implausible GR " << gr);
        CHECK (std::abs (gr - ref) < 0.3, "GR must not depend on sample rate (" << gr << " vs " << ref << ")");
    }
}

void benchmark()
{
    currentTest = "benchmark";
    const double fs = 48000.0;
    auto in = multiTone (fs, (int) (fs * 20), -10.0);
    for (auto q : { dsp::Quality::x1, dsp::Quality::x2, dsp::Quality::x4 })
    {
        OptoEngine e;
        EngineParameters p;
        p.peakReduction = 60.0f; p.quality = q; p.mixPercent = 50.0f;
        e.setParameters (p);
        e.prepare (fs, 2);
        const auto t0 = std::chrono::steady_clock::now();
        auto out = run (e, in, in, 256);
        const double sec = std::chrono::duration<double> (std::chrono::steady_clock::now() - t0).count();
        std::ostringstream os;
        os.precision (3);
        os << "CPU stereo 48 kHz quality " << (int) q << ": " << (100.0 * sec / 20.0) << " % of one core (this VM)";
        report (os.str());
    }
}
} // namespace

int main()
{
    std::cout << "Chioccia core tests\n";
    testHalfBandDesign();
    testOversamplerLatencyAndPassband();
    testReportedLatencyAndNull();
    testImpulseAlignment();
    testDryPathIsClean();
    testMixLinearity();
    testBlockSizeInvariance();
    testRobustness();
    testStereoLink();
    testQualitySwitching();
    testBypass();
    testZeroPeakReduction();
    testSmoothing();
    testCompareMode();
    testMonoAndGainReductionSanity();
    benchmark();
    std::cout << (failures == 0 ? "ALL PASSED" : "FAILURES") << " — " << checks << " checks, " << failures << " failed\n";
    return failures == 0 ? 0 : 1;
}
