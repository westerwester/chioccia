// Chioccia — helpers shared by the core tests and the measurement tool (original code)
#pragma once

#include <cmath>
#include <cstdio>
#include <functional>
#include <random>
#include <string>
#include <vector>

#include "OptoEngine.h"

namespace chioccia::testutil
{
using Buffer = std::vector<float>;
constexpr double kPi = 3.14159265358979323846;

inline Buffer sine (double fs, double freq, double amplitude, int numSamples, double phase = 0.0)
{
    Buffer b ((size_t) numSamples);
    for (int i = 0; i < numSamples; ++i)
        b[(size_t) i] = (float) (amplitude * std::sin (2.0 * kPi * freq * i / fs + phase));
    return b;
}

inline double dbfsToPeak (double dbfs) { return std::pow (10.0, dbfs / 20.0); }
/** Sine peak amplitude for a given RMS level in dBFS. */
inline double rmsDbToSinePeak (double dbRms) { return std::sqrt (2.0) * std::pow (10.0, dbRms / 20.0); }

inline double rmsDb (const Buffer& b, size_t start = 0, size_t end = 0)
{
    if (end == 0 || end > b.size()) end = b.size();
    double s = 0.0;
    for (size_t i = start; i < end; ++i) s += (double) b[i] * b[i];
    return 10.0 * std::log10 (s / (double) std::max<size_t> (1, end - start) + 1.0e-30);
}

/** Amplitude of the component at freq (exact for an integer number of cycles in the window). */
inline double toneAmplitude (const Buffer& b, size_t start, size_t length, double fs, double freq)
{
    double re = 0.0, im = 0.0;
    for (size_t i = 0; i < length; ++i)
    {
        const double w = 2.0 * kPi * freq * (double) i / fs;
        re += b[start + i] * std::cos (w);
        im -= b[start + i] * std::sin (w);
    }
    return 2.0 * std::sqrt (re * re + im * im) / (double) length;
}

struct Stereo { Buffer l, r; };

/** Runs the engine over a stereo (or mono when r is empty) signal with a given block-size policy. */
inline Stereo run (dsp::OptoEngine& e, const Buffer& inL, const Buffer& inR, int blockSize,
                   const std::function<void (int)>& beforeBlock = {}, std::mt19937* randomBlocks = nullptr)
{
    Stereo out { inL, inR };
    const int n = (int) inL.size();
    const int nch = inR.empty() ? 1 : 2;
    int pos = 0;
    std::uniform_int_distribution<int> dist (1, 2048);
    while (pos < n)
    {
        int bs = randomBlocks ? dist (*randomBlocks) : blockSize;
        bs = std::min (bs, n - pos);
        if (beforeBlock) beforeBlock (pos);
        float* ptrs[2] = { out.l.data() + pos, nch == 2 ? out.r.data() + pos : nullptr };
        e.process (ptrs, nch, bs);
        pos += bs;
    }
    return out;
}

inline Buffer delayed (const Buffer& b, int delay)
{
    Buffer d (b.size(), 0.0f);
    for (size_t i = (size_t) delay; i < b.size(); ++i) d[i] = b[i - (size_t) delay];
    return d;
}

inline double maxAbsDiff (const Buffer& a, const Buffer& b, size_t start = 0)
{
    double m = 0.0;
    for (size_t i = start; i < std::min (a.size(), b.size()); ++i) m = std::max (m, (double) std::abs (a[i] - b[i]));
    return m;
}
} // namespace chioccia::testutil
